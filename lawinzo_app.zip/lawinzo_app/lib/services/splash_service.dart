import 'dart:async';


import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lawinzo_app/screens/dashboard_screen.dart';
import 'package:lawinzo_app/screens/login_screen.dart';

import '../utils/utils.dart';

class SplashService{
  void isLogin(BuildContext context){
    final user = Utils.auth.currentUser;
    if(user != null){
      Timer(const Duration(seconds: 3), () {
        Navigator.push(context, MaterialPageRoute(builder: (context)=>  DashboardPage()));
      });
    }else{
      Timer(const Duration(seconds: 3), () {
        Navigator.push(context, MaterialPageRoute(builder: (context)=> const LoginScreen()));
      });    }

  }
}