
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:lawinzo_app/screens/dashboard_screen.dart';
import 'package:lawinzo_app/screens/signup_screen.dart';

import '../utils/utils.dart';

class VerifyOtp extends StatefulWidget {
  final String verificationId;
  const VerifyOtp({Key? key,required this.verificationId}) : super(key: key);

  @override
  State<VerifyOtp> createState() => _VerifyOtpState();
}

class _VerifyOtpState extends State<VerifyOtp> {
  final otpController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Verify Otp "),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextFormField(
              controller: otpController,
              decoration: const InputDecoration(
                  hintText:  "6 digit otp",
                  border: OutlineInputBorder(
                      borderSide: BorderSide(
                          color: Colors.black
                      )
                  )
              ),
            ),
            const SizedBox(height: 30,),
            ElevatedButton(onPressed: () async {
              final credential = PhoneAuthProvider.credential(verificationId: widget.verificationId,
                  smsCode: otpController.text.toString());
              try {
                await Utils.auth.signInWithCredential(credential).then((value) {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> SignupScreen()));
                }).onError((error, stackTrace) {
                  print(error.toString());
                });

              }catch(e){
                print(e.toString());
              }
            }, child: Text("Submit"))
          ],
        ),
      ),
    );
  }
}
