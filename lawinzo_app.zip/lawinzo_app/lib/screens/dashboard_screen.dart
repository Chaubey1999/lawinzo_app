
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:lawinzo_app/screens/login_screen.dart';

import '../utils/utils.dart';

class DashboardPage extends StatefulWidget {
   String? name;
   String? number;
   DashboardPage({Key? key, this.name, this.number}) : super(key: key);

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  @override
  void initState(){
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: const Text("Dashboard"),
        actions: [
          IconButton(onPressed: (){
            Utils.auth.signOut().then((value) {
              Navigator.push(context, MaterialPageRoute(builder: (context)=>const LoginScreen()));
            }).onError((error, stackTrace) {
              Utils().showToast(error.toString());
            });
          }, icon: const Icon(Icons.logout))
        ],
      ),
      body:  Center(
        child: Column(
          children: [
            Text("Hey ${widget.name}",style: const TextStyle(
                fontSize: 24
            ),),
            const SizedBox(height: 20,),
            Text("Contact Number ${widget.number}",style: const TextStyle(
                fontSize: 24
            ),),
          ],
        ),
      ),
    );
  }
}
