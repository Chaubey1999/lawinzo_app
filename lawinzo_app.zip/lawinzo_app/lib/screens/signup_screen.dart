import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:lawinzo_app/screens/dashboard_screen.dart';
import 'package:multi_select_flutter/chip_display/multi_select_chip_display.dart';
import 'package:multi_select_flutter/dialog/multi_select_dialog_field.dart';
import 'package:multi_select_flutter/util/multi_select_item.dart';
import 'package:multi_select_flutter/util/multi_select_list_type.dart';

class SignupScreen extends StatefulWidget {
  @override
  _SignupScreenState createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  TextEditingController _nameController = TextEditingController();
  TextEditingController _phoneController = TextEditingController();
  XFile? _selectedImage;
  List<MultiSelectItem<String>> _educationOptions = [
    MultiSelectItem<String>('Education 1', 'Education 1'),
    MultiSelectItem<String>('Education 2', 'Education 2'),
    MultiSelectItem<String>('Education 3', 'Education 3'),
    MultiSelectItem<String>('Education 4', 'Education 4'),
  ];
  List<String> _selectedEducation = [];
  Future<void> _getImageFromGallery() async {
    final ImagePicker _picker = ImagePicker();
    XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    setState(() {
      _selectedImage = image;
    });
  }
  final _formKey = GlobalKey<FormState>();

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      // Form is valid, proceed with submission
      String name = _nameController.text;
      String phone = _phoneController.text;
      if (_selectedEducation != null) {
        Navigator.push(context, MaterialPageRoute(builder: (context)=>  DashboardPage(
          name: _nameController.text.toString(),
          number: _phoneController.text.toString(),
        )));
      }
    }
  }
  String? _validatePhoneNumber(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a phone number';
    }
    // Custom validation logic (e.g., pattern matching)
    // You can modify this as per your requirements
    String pattern = r'^(?:[+0]9)?[0-9]{10}$';
    RegExp regex = RegExp(pattern);
    if (!regex.hasMatch(value)) {
      return 'Please enter a valid phone number';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile Form'),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Upload Picture field
              CircleAvatar(
                radius: 50.0,
                backgroundImage: _selectedImage != null
                    ? FileImage(File(_selectedImage!.path))
                    : const AssetImage('images/img.png') as ImageProvider,
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: _getImageFromGallery,
                child: const Text('Upload Picture'),
              ),
              const SizedBox(height: 16.0),
              // Name field
              TextFormField(
                controller: _nameController,
                decoration: const InputDecoration(
                  labelText: 'Name',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value!.isEmpty) {
                    return 'Please enter a name';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16.0),
              // Phone number field
              TextFormField(
                controller: _phoneController,
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Phone Number',
                  border: OutlineInputBorder(),
                ),
                validator: _validatePhoneNumber,
              ),
              const SizedBox(height: 16.0),
              // Education field (multiselection)
              // Education field (multi-selection dropdown)
              Text('Education', style: TextStyle(fontSize: 16.0)),
              MultiSelectDialogField<String>(
                items: _educationOptions,
                listType: MultiSelectListType.CHIP,
                onConfirm: (List<String> values) {
                  setState(() {
                    _selectedEducation = values;
                  });

                },
                initialValue: _selectedEducation,
                chipDisplay: MultiSelectChipDisplay(
                  onTap: (value) {
                    setState(() {
                      _selectedEducation.remove(value);
                    });
                  },
                ),
              ),
              const SizedBox(height: 16.0),
              // Submit button
              ElevatedButton(
                onPressed: _submitForm,
                child: const Text('Submit'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}


